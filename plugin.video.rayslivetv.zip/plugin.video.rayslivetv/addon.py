import sys
import os
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import logging
from operator import itemgetter

def show_tags():
  tag_handle = int(sys.argv[1])
  xbmcplugin.setContent(tag_handle, 'tags')

  for tag in tags:
    iconPath = os.path.join(home, 'logos', tag['icon'])
    li = xbmcgui.ListItem(tag['name'], iconImage=iconPath)
    url = sys.argv[0] + '?tag=' + str(tag['id'])
    xbmcplugin.addDirectoryItem(handle=tag_handle, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(tag_handle)


def show_streams(tag):
  stream_handle = int(sys.argv[1])
  xbmcplugin.setContent(stream_handle, 'streams')
  logging.warning('TAG show_streams!!!! %s', tag)
  for stream in streams[str(tag)]:
    logging.debug('STREAM HERE!!! %s', stream['name'])
    iconPath = os.path.join(home, 'logos', stream['icon'])
    li = xbmcgui.ListItem(stream['name'], iconImage=iconPath)
    xbmcplugin.addDirectoryItem(handle=stream_handle, url=stream['url'], listitem=li)

  xbmcplugin.endOfDirectory(stream_handle)


def get_params():
  """
  Retrieves the current existing parameters from XBMC.
  """
  param = []
  paramstring = sys.argv[2]
  if len(paramstring) >= 2:
    params = sys.argv[2]
    cleanedparams = params.replace('?', '')
    if params[len(params) - 1] == '/':
      params = params[0:len(params) - 2]
    pairsofparams = cleanedparams.split('&')
    param = {}
    for i in range(len(pairsofparams)):
      splitparams = {}
      splitparams = pairsofparams[i].split('=')
      if (len(splitparams)) == 2:
        param[splitparams[0]] = splitparams[1]
  return param


def lower_getter(field):
  def _getter(obj):
    return obj[field].lower()

  return _getter


addon = xbmcaddon.Addon()
home = xbmc.translatePath(addon.getAddonInfo('path'))

tags = [
  {
    'name': 'Live TV',
    'id': 'LiveTV',
    'icon': 'livetv.png'
  }, {
    'name': 'Sports Channels',
    'id': 'SportsChannels',
    'icon': 'sports.png'
  }
]


LiveTV = [{
  'name': 'Global Toronto  HD',
  'url': 'http://link.theplatform.com/s/dtjsEC/VhMJVcROT2P4?feed=PROD%20-%20Live%20Stream%20Feed',
  'icon': 'Globalt.png',
  'disabled': False
}, {
  'name': 'Global Calgary  HD',
  'url': 'http://link.theplatform.com/s/dtjsEC/7cZIekSWbaTh?feed=PROD%20-%20Live%20Stream%20Feed',
  'icon': 'Globalc.png',
  'disabled': False
}, {
  'name': 'Global BC  HD',
  'url': 'http://198.144.148.113:9850/live/UHzBk0eoh6/9TeTQDyDBW/50.ts',
  'icon': 'Globalb.png',
  'disabled': False
}, {
  'name': 'Global Edmonton  HD',
  'url': 'http://link.theplatform.com/s/dtjsEC/166zTdtbfhcW?feed=PROD%20-%20Live%20Stream%20Feed',
  'icon': 'Globale.png',
  'disabled': False
}, {
  'name': 'Global Halifax  HD',
  'url': 'http://link.theplatform.com/s/dtjsEC/Hf3kzMuKfZCO?feed=PROD%20-%20Live%20Stream%20Feed',
  'icon': 'Globalh.png',
  'disabled': False
}, {
  'name': 'CHCH Hamilton HD',
  'url': 'http://52.86.189.59:1935/live/news/chunklist.m3u8',
  'icon': 'CHCH.png',
  'disabled': False
}, {
  'name': 'National Geographic  HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/39.m3u8',
  'icon': 'National Geographic.png',
  'disabled': False
}]  

 

 
SportsChannels = [{
  'name': 'TSN1  HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/52.m3u8',
  'icon': 'tsn1.png',
  'disabled': False
}, {
  'name': 'TSN1  HD',
  'url': 'http://iptv.cardsharebox.com:8000/live/widmanphilip/xGCJQAGdd5/2703.ts',
  'icon': 'tsn1.png',
  'disabled': False
}, {
  'name': 'TSN1  HD',
  'url': 'http://89.163.148.31:8000/live/drew/drew/8672.ts',
  'icon': 'tsn1.png',
  'disabled': False
}, {
  'name': 'TSN2  HD',
  'url': 'http://iptv.cardsharebox.com:8000/live/widmanphilip/xGCJQAGdd5/2704.ts',
  'icon': 'tsn2.png',
  'disabled': False
}, {
  'name': 'TSN2 HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/53.m3u8',
  'icon': 'tsn2.png',
  'disabled': False
}, {
  'name': 'TSN2  HD',
  'url': 'http://89.163.148.31:8000/live/drew/drew/8673.ts',
  'icon': 'tsn2.png',
  'disabled': False
}, {
  'name': 'TSN3  HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/54.m3u8',
  'icon': 'tsn3.png',
  'disabled': False
}, {
  'name': 'TSN3 HD',
  'url': 'http://iptv.cardsharebox.com:8000/live/widmanphilip/xGCJQAGdd5/2705.ts',
  'icon': 'tsn3.png',
  'disabled': False
}, {
  'name': 'TSN3  HD',
  'url': 'http://89.163.148.31:8000/live/drew/drew/8674.ts',
  'icon': 'tsn3.png',
  'disabled': False
}, {
  'name': 'TSN4  HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/55.m3u8',
  'icon': 'tsn4.png',
  'disabled': False
}, {
  'name': 'TSN4  HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/55.m3u8',
  'icon': 'tsn4.png',
  'disabled': False
}, {
  'name': 'TSN4  HD',
  'url': 'http://89.163.148.31:8000/live/drew/drew/8675.ts',
  'icon': 'tsn4.png',
  'disabled': False
}, {
  'name': 'TSN5 HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/56.m3u8',
  'icon': 'tsn5.png',
  'disabled': False
}, {
  'name': 'TSN5  HD',
  'url': 'http://46.166.162.35:9090/load/b0922f3fa8aa/56.m3u8',
  'icon': 'tsn5.png',
  'disabled': False
}, {
  'name': 'TSN5  HD',
  'url': 'http://89.163.148.31:8000/live/drew/drew/8676.ts',
  'icon': 'tsn5.png',
  'disabled': False
}]


streams = {
  'LiveTV': sorted((i for i in LiveTV if not i.get('disabled', False)), key=lower_getter('name')),
  'SportsChannels': sorted((i for i in SportsChannels if not i.get('disabled', False)), key=lower_getter('name')),
  # 'LiveTV': sorted(LiveTV, key=lower_getter('name')),
  # 'SportsChannels': sorted(SportsChannels, key=lower_getter('name')),
}

PARAMS = get_params()
TAG = None
logging.warning('PARAMS!!!! %s', PARAMS)

try:
  TAG = PARAMS['tag']
except:
  pass

logging.warning('ARGS!!!! sys.argv %s', sys.argv)

if TAG == None:
  show_tags()
else:
  show_streams(TAG)
